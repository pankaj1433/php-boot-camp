<?php

error_reporting(1);
ini_set('display_errors', 1);

try
{	
$db= new PDO("mysql:host=localhost;dbname=sample","root","abcde");
$name=$_POST['name'];
$pass=$_POST['password'];

$query = $db->prepare("INSERT INTO login (name,password) VALUES (:n,:p)");

$query->bindParam(":n", $name);
$query->bindParam(":p", $pass);
$query->execute();	
//header(location:'login.php');
header("Location: login.php");
}
catch(Exception $ex){
	die('Error :'.$ex->getMessage());
}	
?>