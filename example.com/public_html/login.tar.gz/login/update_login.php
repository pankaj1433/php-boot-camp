<?php

session_start();
error_reporting(1);
ini_set('display_errors', 1);

try
{	
	$db= new PDO("mysql:host=localhost;dbname=sample","root","abcde");
	$pass=$_POST['newpassword'];
	$id=$_SESSION["userid"];
	$_SESSION["pass"]=$_POST['newpassword'];


	$query = $db->prepare("UPDATE login SET password=:p WHERE id=:i");

	$query->bindParam(":i", $id);
	$query->bindParam(":p", $pass);
	$query->execute();	
	
	header("Location: login_register.php?M=update successful");
}
catch(Exception $ex){
	die('Error :'.$ex->getMessage());
}	

?>