<?php
header("Location: files/login.php");
?>